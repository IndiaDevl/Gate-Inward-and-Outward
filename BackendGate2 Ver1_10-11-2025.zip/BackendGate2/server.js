// Version 2 of BackendGate server.js - Fixed and Complete
//require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cookie = require('cookie');

const app = express();
app.use(express.json());

// NOTE: in dev we allow all origins. In production set specific origin.
app.use(cors({ origin: true, credentials: true }));

// // Configure these or set via .env
// const SAP_BASE = process.env.SAP_BASE || 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_GATEINWARD_OUTWARDDETA_CDS';
// const SAP_BASE_WEIGHTBRIDGE = process.env.SAP_BASE_WEIGHTBRIDGE || 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS';
// const SAP_USER = process.env.SAP_USER || 'BTPINTEGRATION';
// const SAP_PASS = process.env.SAP_PASS || 'BTPIntegration@1234567890';
// Configure these or set via .env
const SAP_BASE = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_GATEINWARD_OUTWARDDETA_CDS';
const SAP_BASE_WEIGHTBRIDGE = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS';
const SAP_BASE_InitialRegistration = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_INITIALREGISTRATION_CDS';
const SAP_USER = 'BTPINTEGRATION';
const SAP_PASS = 'BTPIntegration@1234567890';


if (!SAP_BASE || !SAP_USER || !SAP_PASS) {
  console.warn('Make sure SAP_BASE, SAP_USER and SAP_PASS env vars are set');
}

const sapAxios = axios.create({
  baseURL: SAP_BASE,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});

const sapAxiosWeight = axios.create({
  baseURL: SAP_BASE_WEIGHTBRIDGE,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});

const sapAxiosInitialRegistration = axios.create({
  baseURL: SAP_BASE_InitialRegistration,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});
/* ---------- Utility helpers ---------- */

async function fetchCsrfToken() {
  try {
    const res = await sapAxios.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfToken error', err?.response?.status, err?.message);
    throw err;
  }
}

async function fetchCsrfTokenWeight() {
  try {
    const res = await sapAxiosWeight.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenWeight error', err?.response?.status, err?.message);
    throw err;
  }
}

/**
 * Fetch CSRF token + cookies for Initial Registration OData service.
 */
async function fetchCsrfTokenInitialRegistration() {
  try {
    const res = await sapAxiosInitialRegistration.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();

    if (!token) {
      console.warn('[WARN] No CSRF token returned for Initial Registration fetch');
    }
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenInitialRegistration error', err?.response?.status, err?.message);
    throw err;
  }
}

function sanitizePayloadForSapServerSide(input) {
  const payload = JSON.parse(JSON.stringify(input || {}));

  // Remove undefined/null and empty strings for top-level keys
  // BUT PRESERVE WeightDocNumber (the correct SAP field name)
  Object.keys(payload).forEach(k => {
    // Skip WeightDocNumber - let SAP validate it
    if (k === 'WeightDocNumber') return;
    
    if (payload[k] === undefined || payload[k] === null) delete payload[k];
    if (typeof payload[k] === 'string' && payload[k].trim() === '') delete payload[k];
  });

  // Normalize date if only date provided
  if (payload.GateEntryDate && payload.GateEntryDate.length === 10) {
    payload.GateEntryDate = `${payload.GateEntryDate}T00:00:00`;
  }
  if (payload.GateOutDate && payload.GateOutDate.length === 10) {
    payload.GateOutDate = `${payload.GateOutDate}T00:00:00`;
  }

  // Numeric cleaning for vendor weights and balances if provided as header-level fields
  for (let i = 1; i <= 5; i++) {
    const suffix = i === 1 ? '' : String(i);
    const wKey = `VendorInvoiceWeight${suffix}`;
    const bKey = `BalanceQty${suffix}`;

    if (wKey in payload) {
      const raw = payload[wKey];
      if (raw === '' || raw === null || raw === undefined) delete payload[wKey];
      else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[wKey] = normalized;
        } else {
          delete payload[wKey];
        }
      }
    }

    if (bKey in payload) {
      const raw = payload[bKey];
      if (raw === '' || raw === null || raw === undefined) delete payload[bKey];
      else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[bKey] = normalized;
        } else {
          delete payload[bKey];
        }
      }
    }
  }

  // Clean other numeric fields (TruckCapacity, TareWeight, GrossWeight, NetWeght, etc.)
  const numericFields = [
    'TruckCapacity', 'TareWeight', 'GrossWeight', 'NetWeght', 
    'DifferenceBT', 'ToleranceWeight', 'ActuallyWeight'
  ];
  
  numericFields.forEach(field => {
    if (field in payload) {
      const raw = payload[field];
      if (raw === '' || raw === null || raw === undefined) {
        delete payload[field];
      } else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[field] = normalized;
        } else {
          delete payload[field];
        }
      }
    }
  });

  return payload;
}

/* ---------- GateEntryNumber generator helpers ---------- */

// Build prefix like '251' (YY + series code)
function buildPrefixFromYearAndCode(yearInput, codeInput) {
  const now = new Date();
  const year = (yearInput && String(yearInput).length === 4) ? String(yearInput) : String(now.getFullYear());
  const yy = year.slice(-2);
  const code = String(codeInput || '1');
  return `${yy}${code}`; // e.g. '253' when year=2025 and code=3
}

function computeNextGateEntryNumber(prefix, latestGateNumber) {
  const suffixLength = 7; // 3(prefix) + 7 = 10 digits
  if (!latestGateNumber) return `${prefix}${String(1).padStart(suffixLength, '0')}`;
  const suffix = latestGateNumber.slice(prefix.length);
  const next = (parseInt(suffix, 10) || 0) + 1;
  return `${prefix}${String(next).padStart(suffixLength, '0')}`;
}

function computeNextWeightDocNumber(prefix, latestWeightNumber) {
  const suffixLength = 7; // 3(prefix) + 7 = 10 digits
  if (!latestWeightDocNumber) return `${prefix}${String(1).padStart(suffixLength, '0')}`;
  const suffix = latestWeightDocNumber.slice(prefix.length);
  const next = (parseInt(suffix, 10) || 0) + 1;
  return `${prefix}${String(next).padStart(suffixLength, '0')}`;
}

// Fetch latest gate entry number from SAP matching the prefix
async function getLatestGateEntryNumberFromSap(prefix) {
  try {
    const filter = `startswith(GateEntryNumber,'${prefix}')`;
    const path = `/YY1_GATEINWARD_OUTWARDDETA?$filter=${filter}&$orderby=GateEntryNumber desc&$top=1&$format=json`;
    const resp = await sapAxios.get(path);
    const results = resp.data?.d?.results || [];
    return results.length > 0 ? results[0].GateEntryNumber : null;
  } catch (err) {
    console.error('getLatestGateEntryNumberFromSap error', err?.message);
    return null;
  }
}

// Fetch latest weight document number from SAP matching the prefix
async function getLatestWeightDocNumberFromSap(prefix) {
  try {
    const filter = `startswith(WeightDocNumber,'${prefix}')`;
    const path = `/YY1_CAPTURINGWEIGHTDETAILS?$filter=${filter}&$orderby=WeightDocNumber desc&$top=1&$format=json`;
    console.log('[DEBUG] Fetching latest WeightDocNumber with path:', path);
    
    const resp = await sapAxiosWeight.get(path);
    console.log('[DEBUG] Weight query response:', JSON.stringify(resp.data, null, 2));
    
    const results = resp.data?.d?.results || [];
    const latestNumber = results.length > 0 ? results[0].WeightDocNumber : null;
    console.log('[DEBUG] Latest WeightDocNumber found:', latestNumber);
    
    return latestNumber;
  } catch (err) {
    console.error('getLatestWeightDocNumberFromSap error', err?.response?.status, err?.response?.data || err?.message);
    return null;
  }
}

/* ---------- API Routes ---------- */

// Simple request logger for debugging
app.use((req, res, next) => {
  console.log(`[API] ${req.method} ${req.originalUrl}`);
  if (Object.keys(req.body || {}).length) console.log(' body:', JSON.stringify(req.body));
  next();
});

// GET next gate number: /api/next-gatenumber?year=2025&code=3
app.get('/api/next-gatenumber', async (req, res) => {
  try {
    const { year, code } = req.query;
    const prefix = buildPrefixFromYearAndCode(year, code);
    const latest = await getLatestGateEntryNumberFromSap(prefix);
    const nextNumber = computeNextGateEntryNumber(prefix, latest);
    return res.json({ next: nextNumber });
  } catch (e) {
    console.error('next-gatenumber error', e?.response?.data || e.message);
    res.status(500).json({ error: e?.response?.data || e.message });
  }
});

// GET next weight number: /api/next-weightnumber?year=2025&code=1
app.get('/api/next-weightnumber', async (req, res) => {
  try {
    const { year, code } = req.query;
    const prefix = buildPrefixFromYearAndCode(year, code);
    console.log('[DEBUG] Generating next weight number for prefix:', prefix);
    
    const latest = await getLatestWeightDocNumberFromSap(prefix);
    const nextNumber = computeNextWeightDocNumber(prefix, latest);
    
    console.log('[DEBUG] Next WeightDocNumber:', nextNumber);
    return res.json({ next: nextNumber });
  } catch (e) {
    console.error('next-weightnumber error', e?.response?.data || e.message);
    res.status(500).json({ error: e?.response?.data || e.message });
  }
});

/* GET headers with query forwarding */
app.get('/api/headers', async (req, res) => {
  try {
    const rawQuery = (req.originalUrl || '').split('?')[1] || '';
    const sapPath = rawQuery ? `/YY1_GATEINWARD_OUTWARDDETA?${rawQuery}` : '/YY1_GATEINWARD_OUTWARDDETA?$top=50&$format=json';
    console.log('[API] forwarding to SAP ->', sapPath);
    const resp = await sapAxios.get(sapPath);
    res.json(resp.data);
  } catch (err) {
    console.error('Error fetching gate entry:', err?.response?.status, err?.response?.data || err?.message);
    res.status(500).json({ error: err?.response?.data || err?.message || 'Failed to fetch gate entry details' });
  }
});

/* GET header by GUID */
app.get('/api/headers/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const resp = await sapAxios.get(`/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')?$format=json`);
    res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* GET items for a header */
app.get('/api/headers/:id/items', async (req, res) => {
  const id = req.params.id;
  try {
    const path = `/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')/to_GateEntryItems?$format=json`;
    const resp = await sapAxios.get(path);
    res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST new header (deep insert with items) - Gate Entry */
app.post('/api/headers', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    const { token, cookies } = await fetchCsrfToken();

    const resp = await sapAxios.post('/YY1_GATEINWARD_OUTWARDDETA', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST header error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST Material Inward - Weight Bridge */
app.post('/api/headers/material/in', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    
    // Ensure WeightDocNumber exists (SAP requires it)
    // Note: The field is WeightDocNumber (not WeightDocumentNumber)
    if (!input.WeightDocNumber) {
      console.error('[ERROR] WeightDocNumber is missing!');
      return res.status(400).json({ 
        error: 'WeightDocNumber is required. Please ensure it is generated on the frontend.' 
      });
    }

    const { token, cookies } = await fetchCsrfTokenWeight();

    console.log('[DEBUG] Sanitized payload for Material Inward:', JSON.stringify(input, null, 2));

    const resp = await sapAxiosWeight.post('/YY1_CAPTURINGWEIGHTDETAILS', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Material Inward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST Material Outward - Weight Bridge */
app.post('/api/headers/material/out', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    
    // Ensure WeightDocNumber exists (SAP requires it)
    if (!input.WeightDocNumber) {
      console.error('[ERROR] WeightDocNumber is missing!');
      return res.status(400).json({ 
        error: 'WeightDocNumber is required. Please ensure it is generated on the frontend.' 
      });
    }

    const { token, cookies } = await fetchCsrfTokenWeight();

    console.log('[DEBUG] Sanitized payload for Material Outward:', JSON.stringify(input, null, 2));

    const resp = await sapAxiosWeight.post('/YY1_CAPTURINGWEIGHTDETAILS', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Material Outward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH update header */
app.patch('/api/headers/:id', async (req, res) => {
  const id = req.params.id;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')`;
    const resp = await sapAxios.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH header error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST create item under existing header */
app.post('/api/headers/:id/items', async (req, res) => {
  const id = req.params.id;
  const item = req.body;
  try {
    const { token, cookies } = await fetchCsrfToken();

    const resp = await sapAxios.post('/YY1_GATEENTRYITEMS_GATEINWA000', {
      ...item,
      SAP_PARENT_UUID: id
    }, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      }
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH update item */
app.patch('/api/items/:id', async (req, res) => {
  const id = req.params.id;
  const body = req.body;
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEENTRYITEMS_GATEINWA000(guid'${id}')`;
    const resp = await sapAxios.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* DELETE item */
app.delete('/api/items/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEENTRYITEMS_GATEINWA000(guid'${id}')`;
    const resp = await sapAxios.delete(path, {
      headers: {
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('DELETE item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});




const SAP_URL2 =
  "https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS/YY1_CAPTURINGWEIGHTDETAILS";
const SAP_USER2 = "BTPINTEGRATION";
const SAP_PASS2 = "BTPIntegration@1234567890";
app.get("/api/header/weightdetails", async (req, res) => {
  try {
    const gateNumber = req.query.gateEntryNumber || req.query.GateEntryNumber;
    if (!gateNumber) {
      return res.status(400).json({ error: "Missing required parameter: gateNumber" });
    }

    // Proper OData filter string
    const filter = `$filter=GateEntryNumber eq '${gateNumber}'&$format=json`;
    const fullUrl = `${SAP_URL2}?${filter}`;

    console.log("[INFO] Fetching SAP Weight Details →", fullUrl);

    // Perform the SAP OData request
    const response = await axios.get(fullUrl, {
      auth: { username: SAP_USER2, password: SAP_PASS2 },
      headers: { Accept: "application/json" },
      validateStatus: () => true // prevents throwing error on 4xx
    });

    if (response.status >= 400) {
      console.error("[SAP ERROR]", response.status, response.data);
      return res.status(response.status).json({
        error: response.data || `SAP returned status ${response.status}`
      });
    }

    // Parse SAP OData V2 format
    const results =
      response.data?.d?.results || response.data?.value || (response.data?.d ? [response.data.d] : []);

    console.log(`[INFO] SAP returned ${results.length} record(s)`);

    // Filter only Indicators = "I" (Inward)
    const filteredResults = results.filter((r) => (r.Indicators || "").toUpperCase() === "I");

    // Return consistent JSON
    return res.json({
      d: {
        results: filteredResults
      }
    });
  } catch (error) {
    console.error("[API ERROR]", error.response?.status, error.response?.data || error.message);
    return res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message || "Failed to fetch SAP data"
    });
  }
});

// GET Material Outward records (Indicators='O')
app.get("/api/header/weightdetails/outward", async (req, res) => {
  try {
    const gateNumber = req.query.gateEntryNumber || req.query.GateEntryNumber;
    if (!gateNumber) {
      return res.status(400).json({ error: "Missing required parameter: gateEntryNumber" });
    }

    const filter = `$filter=GateEntryNumber eq '${gateNumber}'&$format=json`;
    const fullUrl = `${SAP_URL2}?${filter}`;

    console.log("[INFO] Fetching SAP Weight Details (Outward) →", fullUrl);

    const response = await axios.get(fullUrl, {
      auth: { username: SAP_USER2, password: SAP_PASS2 },
      headers: { Accept: "application/json" },
      validateStatus: () => true
    });

    if (response.status >= 400) {
      console.error("[SAP ERROR]", response.status, response.data);
      return res.status(response.status).json({
        error: response.data || `SAP returned status ${response.status}`
      });
    }

    const results =
      response.data?.d?.results || response.data?.value || (response.data?.d ? [response.data.d] : []);

    console.log(`[INFO] SAP returned ${results.length} record(s)`);

    // Filter only Indicators = "O" (Outward)
    const filteredResults = results.filter((r) => (r.Indicators || "").toUpperCase() === "O");

    return res.json({
      d: {
        results: filteredResults
      }
    });
  } catch (error) {
    console.error("[API ERROR]", error.response?.status, error.response?.data || error.message);
    return res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message || "Failed to fetch SAP data"
    });
  }
});


/* PATCH Update Material Inward (for tare weight) */
app.patch('/api/headers/material/:uuid', async (req, res) => {
  const uuid = req.params.uuid;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfTokenWeight();
    
    // REMOVE $format=json from PATCH - SAP doesn't allow query options on updates
    const path = `/YY1_CAPTURINGWEIGHTDETAILS(guid'${uuid}')`;
    
    console.log('[DEBUG] Updating Material Inward:', path);
    console.log('[DEBUG] Update payload:', JSON.stringify(body, null, 2));
    
    const resp = await sapAxiosWeight.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH Material Inward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

// Initial Registration POST
app.post('/api/initial-registration', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    const { token, cookies } = await fetchCsrfTokenInitialRegistration();
    const resp = await sapAxiosInitialRegistration.post('/YY1_INITIALREGISTRATION', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Initial Registration error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* GET Initial Registration list with optional search and count */
app.get('/api/initial-registrations', async (req, res) => {
  try {
    const top = Math.min(parseInt(req.query.top, 10) || 50, 200); // safety cap
    const search = (req.query.search || '').trim();
    const wantCount = String(req.query.count || 'false').toLowerCase() === 'true';

    // Build OData $filter using substringof (OData V2 compatible)
    let filterExpr = '';
    if (search) {
      const s = search.replace(/'/g, "''"); // escape single quotes for OData
      // Use substringof instead of contains - OData V2 syntax
      const clauses = [
        `substringof('${s}',SalesDocument)`,
        `substringof('${s}',VehicleNumber)`,
        `substringof('${s}',Transporter)`,
        `substringof('${s}',SAP_Description)`
      ];
      filterExpr = clauses.join(' or ');
    }

    let path = `/YY1_INITIALREGISTRATION?$format=json&$top=${top}`;
    if (filterExpr) path += `&$filter=${encodeURIComponent(filterExpr)}`;
    if (wantCount) path += `&$inlinecount=allpages`;

    console.log('[DEBUG] Initial Registration query path:', path);

    const resp = await sapAxiosInitialRegistration.get(path);

    // Normalize OData V2 shape
    const d = resp.data?.d || {};
    const results = Array.isArray(d.results) ? d.results : (Array.isArray(resp.data?.value) ? resp.data.value : []);
    const count = d.__count != null ? Number(d.__count) : results.length;

    return res.json({ d: { __count: count, results } });
  } catch (err) {
    console.error('GET Initial Registrations error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH Update Initial Registration (e.g., change Status to Failed) */
app.patch('/api/initial-registration/:uuid', async (req, res) => {
  const uuid = req.params.uuid;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfTokenInitialRegistration();
    const path = `/YY1_INITIALREGISTRATION(guid'${uuid}')`;
    
    console.log('[DEBUG] Updating Initial Registration:', path, body);
    
    const resp = await sapAxiosInitialRegistration.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH Initial Registration error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

// Start server
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));


