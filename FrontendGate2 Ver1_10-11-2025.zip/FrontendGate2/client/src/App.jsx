import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate, useNavigate } from "react-router-dom";
import InitialRegistration from  "./pages/Gateinmovementin/InitialReg.jsx";
import CreateHeader from "./pages/Gateinmovementin/CreateHeader.jsx";
import MoveINHome from "./pages/Gateinmovementin/MoveINHome.jsx";
import MoveOutHome from "./pages/GateMovementOut/GateOutHome.jsx";
import MaterialINHome from "./pages/MaterialMovementIN/MaterialINHome.jsx";
import MaterialInward from "./pages/MaterialMovementIN/MaterialInward.jsx";
import MaterialOutward from "./pages/MaterialMovementIN/MaterialOutward.jsx";
import MaterialOutHome from "./pages/MaterialMovementOut/MaterialOutHome.jsx";  
import MaterialOut_Inward from "./pages/MaterialMovementOut/MatInward_out.jsx";
import MaterialOut_Outward from "./pages/MaterialMovementOut/MatOutward_out.jsx";
import Outward from "./pages/Gateinmovementin/Outward.jsx";
import GateOut_Inward from "./pages/GateMovementOut/GateEntryInward_Out.jsx";
import GateOut_Outward from "./pages/GateMovementOut/GateEntryOutward_Out.jsx";
import "./App.css";

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const loggedIn = localStorage.getItem("loggedIn") === "true";
  return loggedIn ? children : <Navigate to="/" replace />;
};

// Home Page Component
const HomePage = () => {
  const navigate = useNavigate();
  
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Gate Entry</h1>
        <nav className="main-nav">
          <Link to="/home" className="nav-link">Dashboard</Link>
          <Link to="/home/initial_registration" className="nav-link">Initial Registration</Link>
          <button 
            onClick={() => { localStorage.removeItem("loggedIn"); navigate("/"); }}
            className="logout-btn"
          >
            Logout
          </button>
        </nav>
      </header>

      <main className="home-main">
        <div className="dashboard-cards">
          <div className="card">
            <h3>Gate Entry Movement In</h3>
            <p>Gate movement in</p>
            <Link to="/home/movein" className="card-link">Gate Entry Movement IN</Link>
          </div>
          <div className="card">
            <h3>Material Movement Details IN</h3>
            <p>Gate Material Details</p>
            <Link to="/home/Materialin" className="card-link">Material Movement Details IN</Link>
          </div>
          <div className="card">
            <h3>Material Movement Details Out</h3>
            <p>Gate Material Details</p>
            <Link to="/home/materialout" className="card-link">Material Movement Details Out</Link>
          </div>
          <div className="card">
            <h3>Gate Entry Movement Out</h3>
            <p>Gate Movement Out Details</p>
            <Link to="/home/moveout" className="card-link">Gate Entry Movement Out</Link>
          </div>
        </div>
      </main>
    </div>
  );
};

// Login Page Component
const LoginPage = () => {
  const [user, setUser] = useState("");
  const [pwd, setPwd] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (user === "admin" && pwd === "admin") {
      localStorage.setItem("loggedIn", "true");
      navigate("/home");
    } else {
      setError("Invalid credentials. Use admin/admin");
    }
  };

  return (
    <div className="login-container">


      <div className="login-card">
        <h2>Gate Entry System</h2>
        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <label>Username</label>
            <input 
              type="text"
              value={user}
              onChange={(e) => setUser(e.target.value)}
              placeholder="Enter username"
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input 
              type="password"
              value={pwd}
              onChange={(e) => setPwd(e.target.value)}
              placeholder="Enter password"
            />
          </div>
          {error && <div className="error-message">{error}</div>}
          <button type="submit" className="login-btn">Login</button>
          <p className="help-text">Demo credentials: admin / admin</p>
        </form>
      </div>
    </div>
  );
};

// Main App Component
export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/home" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
        <Route path="/home/initial_registration" element={<ProtectedRoute><InitialRegistration /></ProtectedRoute>} />
        <Route path="/home/create" element={<ProtectedRoute><CreateHeader /></ProtectedRoute>} />
        <Route path="/home/movein" element={<ProtectedRoute><MoveINHome /></ProtectedRoute>} />
        <Route path="/home/moveout" element={<ProtectedRoute><MoveOutHome /></ProtectedRoute>} />
        <Route path="/home/materialin" element={<ProtectedRoute><MaterialINHome /></ProtectedRoute>} />
        <Route path="/home/materialinward" element={<ProtectedRoute><MaterialInward /></ProtectedRoute>} />
        <Route path="/home/materialoutward" element={<ProtectedRoute><MaterialOutward /></ProtectedRoute>} />
        <Route path="/home/materialout" element={<ProtectedRoute><MaterialOutHome /></ProtectedRoute>} />
        <Route path="/home/materialout_inward" element={<ProtectedRoute><MaterialOut_Inward /></ProtectedRoute>} />
        <Route path="/home/movein/inward" element={<ProtectedRoute><CreateHeader /></ProtectedRoute>} />
        <Route path="/home/movein/outward" element={<ProtectedRoute><Outward /></ProtectedRoute>} />
        <Route path="/home/materialout_outward" element={<ProtectedRoute><MaterialOut_Outward /></ProtectedRoute>} />
        <Route path="/home/gateout_inward" element={<ProtectedRoute><GateOut_Inward /></ProtectedRoute>} />
        <Route path="/home/gateout_outward" element={<ProtectedRoute><GateOut_Outward /></ProtectedRoute>} />
      </Routes>
    </Router>
  );
}
