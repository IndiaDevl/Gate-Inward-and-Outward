// Version 4 Automatic time and date working fine
import React, { useState, useEffect } from "react";
import { createHeader, fetchNextGateNumber } from "../../api";
import { useLocation } from "react-router-dom";
import "./CreateHeader.css";

export default function CreateHeader() {
  const currentDate = new Date().toISOString().split('T')[0];
  const currentYear = new Date().getFullYear().toString();

  // Helper: Format current time into SAP duration string e.g. PT16H42M16S
  const formatTimeToSapDuration = (date = new Date()) => {
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');
    return `PT${hh}H${mm}M${ss}S`;
  };

  // Helper: Full ISO timestamp (UTC) for SAP_CreatedDateTime
  const nowIso = (date = new Date()) => date.toISOString();

  // Create initial state function to avoid reference issues
  const createInitialHeaderState = () => {
    const initialState = {
      // Header fields
      GateEntryNumber: "",
      GateEntryDate: currentDate,
      VehicleNumber: "",
      TransporterName: "",
      DriverName: "",
      DriverPhoneNumber: "",
      PermitNumber: "",
      EWayBill: false,
      Division: "",
      Remarks: "",
      FiscalYear: currentYear, // Add FiscalYear explicitly

      // automatic timestamps (initial values) — ensure time shows correctly
      InwardTime: new Date().toISOString().includes('T')
        ? `${new Date().getHours().toString().padStart(2, '0')}:${new Date().getMinutes().toString().padStart(2, '0')}:${new Date().getSeconds().toString().padStart(2, '0')}`
        : '',
      OutwardTime: new Date().toISOString().includes('T')
        ? `${new Date().getHours().toString().padStart(2, '0')}:${new Date().getMinutes().toString().padStart(2, '0')}:${new Date().getSeconds().toString().padStart(2, '0')}`
        : '',
      SAP_CreatedDateTime: new Date().toISOString(),

    };

    // Add PO fields dynamically
    for (let i = 1; i <= 5; i++) {
      const suffix = i === 1 ? "" : String(i);
      initialState[`PurchaseOrderNumber${suffix}`] = "";
      initialState[`Material${suffix}`] = "";
      initialState[`MaterialDescription${suffix}`] = "";
      initialState[`Vendor${suffix}`] = "";
      initialState[`VendorName${suffix}`] = "";
      initialState[`VendorInvoiceNumber${suffix}`] = "";
      initialState[`VendorInvoiceWeight${suffix}`] = "";
      initialState[`BalanceQty${suffix}`] = "";
    }

    return initialState;
  };

  const [header, setHeader] = useState(createInitialHeaderState());
  const [series, setSeries] = useState("2");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    // Special handling for numeric fields to allow decimals
    if (name.includes('VendorInvoiceWeight') || name.includes('BalanceQty')) {
      // Allow numbers, decimal point, and empty string
      if (value === '' || /^-?\d*\.?\d*$/.test(value)) {
        setHeader(prev => ({ ...prev, [name]: value }));
      }
    } else {
      setHeader(prev => ({
        ...prev,
        [name]: type === "checkbox" ? checked : value
      }));
    }
  };

  // Auto-generate GateEntryNumber and set FiscalYear
  useEffect(() => {
    let mounted = true;

    const generateGateNumber = async () => {
      try {
        const year = header.GateEntryDate ? header.GateEntryDate.slice(0, 4) : currentYear;
        const resp = await fetchNextGateNumber(year, series);
        if (!mounted) return;
        if (resp?.data?.next) {
          setHeader(h => ({ ...h, GateEntryNumber: resp.data.next }));
        }
      } catch (err) {
        console.warn('fetchNextGateNumber failed, using fallback', err);
        const year = header.GateEntryDate ? header.GateEntryDate.slice(2, 4) : currentYear.slice(2, 4);
        const seriesPrefix = series === '2' ? 2 : 'SD';
        const fallbackNumber = `${year}${seriesPrefix}0000001`;
        setHeader(h => ({ ...h, GateEntryNumber: fallbackNumber }));
      }
    };

    // Update FiscalYear when GateEntryDate changes
    if (header.GateEntryDate) {
      const year = header.GateEntryDate.slice(0, 4);
      setHeader(prev => ({ ...prev, FiscalYear: year }));
    }

    generateGateNumber();

    return () => { mounted = false; };
  }, [header.GateEntryDate, series, currentYear]);

  // Add data transformation before sending to API
  const transformDataForAPI = (data) => {
    const transformed = { ...data };

    // Helper to normalize a decimal input and return string or null
    const normalizeDecimalString = (val) => {
      if (val === '' || val === null || val === undefined) return null;
      // Accept numbers or numeric-like strings; remove thousands separators (commas)
      const s = String(val).trim().replace(/,/g, '');
      // normalize comma decimal separators to dot
      const normalized = s.replace(/\s+/g, '').replace(',', '.');
      // validate numeric pattern
      if (/^-?\d+(\.\d+)?$/.test(normalized)) {
        // return as string (no Number conversion) because SAP Edm.Decimal often expects quoted string
        return normalized;
      }
      return null;
    };

    for (let i = 1; i <= 5; i++) {
      const suffix = i === 1 ? "" : String(i);

      const weightField = `VendorInvoiceWeight${suffix}`;
      const qtyField = `BalanceQty${suffix}`;

      transformed[weightField] = normalizeDecimalString(transformed[weightField]);
      transformed[qtyField] = normalizeDecimalString(transformed[qtyField]);
    }

    // Ensure EWayBill is boolean
    transformed.EWayBill = Boolean(transformed.EWayBill);

    // If you included other decimal fields in future, normalize here as well

    return transformed;
  };

  // helper: convert "HH:mm:ss" or Date() -> "PT#H#M#S"
  const hhmmssToSapDuration = (val) => {
    if (!val) return null;
    if (typeof val === 'string' && /^\d{2}:\d{2}:\d{2}$/.test(val)) {
      const [h, m, s] = val.split(':').map(v => parseInt(v, 10));
      return `PT${h}H${m}M${s}S`;
    }
    // if val is Date
    if (val instanceof Date) {
      return formatTimeToSapDuration(val);
    }
    return String(val);
  };

  // helper: extract readable message from SAP / axios error
  const extractErrorMessage = (err) => {
    const resp = err?.response?.data;
    if (!resp) return err?.message || String(err);
    // SAP OData typical shape: { error: { message: { lang, value }, ... } }
    if (resp.error?.message?.value) return resp.error.message.value;
    if (resp.error?.message) return typeof resp.error.message === 'string' ? resp.error.message : JSON.stringify(resp.error.message);
    if (resp.message) return typeof resp.message === 'string' ? resp.message : JSON.stringify(resp.message);
    return JSON.stringify(resp);
  };

  // Update the handleSubmit function with better error handling
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // prepare times as SAP durations (adjust if backend expects plain HH:mm:ss)
      const inbound = header.InwardTime || `${new Date().getHours().toString().padStart(2,'0')}:${new Date().getMinutes().toString().padStart(2,'0')}:${new Date().getSeconds().toString().padStart(2,'0')}`;
      const outbound = header.OutwardTime || inbound;

      // build payload and normalize numeric fields
      const rawPayload = {
        ...header,
        GateEntryDate: `${header.GateEntryDate}T00:00:00`,
        InwardTime: hhmmssToSapDuration(header.InwardTime || inbound),
        // OutwardTime: set only for outward or when present
        OutwardTime: mode === "outward" ? hhmmssToSapDuration(outbound) : (header.OutwardTime ? hhmmssToSapDuration(header.OutwardTime) : null),
        SAP_CreatedDateTime: nowIso(),
        FiscalYear: header.FiscalYear || currentYear
      };

      const payload = transformDataForAPI(rawPayload); // apply decimal normalization etc.
      console.debug('Sending payload', payload);

      const response = await createHeader(payload);
      setResult(response.data || 'Gate entry created successfully');
      resetForm();
    } catch (err) {
      console.error('Submit error - full response:', err?.response?.data || err);
      const msg = extractErrorMessage(err);
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setHeader(createInitialHeaderState());
    setError(null);
    setResult(null);
  };

  // detect mode from URL path (inward / outward)
  const location = useLocation();
  const pathTail = location.pathname.split("/").pop(); // "inward" or "outward" or "create"
  const mode = pathTail === "inward" ? "inward" : (pathTail === "outward" ? "outward" : "default");

  // if mode is inward, ensure OutwardTime is null and InwardTime set to current HH:mm:ss
  useEffect(() => {
    if (mode === "inward") {
      const hh = String(new Date().getHours()).padStart(2, "0");
      const mm = String(new Date().getMinutes()).padStart(2, "0");
      const ss = String(new Date().getSeconds()).padStart(2, "0");
      setHeader(h => ({ ...h, InwardTime: `${hh}:${mm}:${ss}`, OutwardTime: "" }));
    }
    if (mode === "outward") {
      // For outward you might want to leave InwardTime and set OutwardTime at submit
      setHeader(h => ({ ...h, OutwardTime: "" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  // update the title shown to user
  return (
    <div className="create-header-container">
      <h2 className="page-title">
        {mode === "inward" ? "Create Gate Entry (Inward)" : 
         mode === "outward" ? "Create Gate Entry (Outward)" : 
         "Create Gate Entry"}
      </h2>

      <form onSubmit={handleSubmit}>
        <section className="form-section">
          <h3 className="section-title">Header Information</h3>
          <div className="grid-3-cols">
            <div className="form-group">
              <label className="form-label">Gate Entry Number *</label>
              <input
                className="form-input"
                name="GateEntryNumber"
                value={header.GateEntryNumber}
                readOnly
              />
            </div>

            <div className="form-group">
              <label className="form-label">Gate Entry Date *</label>
              <input
                className="form-input"
                name="GateEntryDate"
                type="date"
                value={header.GateEntryDate}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Series</label>
              <select className="form-select" value={series} onChange={(e) => setSeries(e.target.value)}>
                {/* <option value="1">SD Series</option> */}
                <option value="2">MM Series</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Vehicle Number *</label>
              <input
                className="form-input"
                name="VehicleNumber"
                value={header.VehicleNumber}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Transporter Name</label>
              <input
                className="form-input"
                name="TransporterName"
                value={header.TransporterName}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Driver Name</label>
              <input
                className="form-input"
                name="DriverName"
                value={header.DriverName}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Driver Phone</label>
              <input
                className="form-input"
                name="DriverPhoneNumber"
                value={header.DriverPhoneNumber}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Permit Number</label>
              <input
                className="form-input"
                name="PermitNumber"
                value={header.PermitNumber}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Division</label>
              <input
                className="form-input"
                name="Division"
                value={header.Division}
                onChange={handleChange}
              />
            </div>

            <div className="form-group form-group-checkbox">
              <input type="checkbox" className="form-checkbox" name="EWayBill" checked={header.EWayBill} onChange={handleChange} />
              <label className="form-checkbox-label">E-Way Bill</label>
            </div>

            <div className="form-group">
              <label className="form-label">Inward Time (auto)</label>
              <input
                className="form-input"
                name="InwardTime"
                value={header.InwardTime}
                readOnly
              />
            </div>

            <div className="form-group">
              <label className="form-label">Outward Time (will be set at submit)</label>
              <input
                className="form-input"
                name="OutwardTime"
                value={header.OutwardTime}
                readOnly
              />
            </div>

            <div className="form-group full-width">
              <label className="form-label">Remarks</label>
              <textarea
                className="form-textarea"
                name="Remarks"
                value={header.Remarks}
                onChange={handleChange}
                rows={2}
              />
            </div>
          </div>
        </section>

        <section className="form-section">
          <h3 className="section-title">Purchase Order Details</h3>
          {Array.from({ length: 5 }).map((_, idx) => {
            const suffix = idx === 0 ? "" : String(idx + 1);
            return (
              <div key={idx} className="po-entry-card">
                <h4 className="po-entry-title">PO Entry {idx + 1}</h4>
                <div className="grid-4-cols">
                  <div className="form-group">
                    <label className="form-label">PO Number</label>
                    <input
                      className="form-input"
                      name={`PurchaseOrderNumber${suffix}`}
                      value={header[`PurchaseOrderNumber${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Material</label>
                    <input
                      className="form-input"
                      name={`Material${suffix}`}
                      value={header[`Material${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Material Description</label>
                    <input
                      className="form-input"
                      name={`MaterialDescription${suffix}`}
                      value={header[`MaterialDescription${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Vendor</label>
                    <input
                      className="form-input"
                      name={`Vendor${suffix}`}
                      value={header[`Vendor${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Vendor Name</label>
                    <input
                      className="form-input"
                      name={`VendorName${suffix}`}
                      value={header[`VendorName${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Vendor Invoice No</label>
                    <input
                      className="form-input"
                      name={`VendorInvoiceNumber${suffix}`}
                      value={header[`VendorInvoiceNumber${suffix}`]}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Vendor Invoice Weight</label>
                    <input
                      className="form-input"
                      name={`VendorInvoiceWeight${suffix}`}
                      type="text"
                      inputMode="decimal"
                      value={header[`VendorInvoiceWeight${suffix}`]}
                      onChange={handleChange}
                      placeholder="0.00"
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Balance Quantity</label>
                    <input
                      className="form-input"
                      name={`BalanceQty${suffix}`}
                      type="text"
                      inputMode="decimal"
                      value={header[`BalanceQty${suffix}`]}
                      onChange={handleChange}
                      placeholder="0.000"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </section>

        <div className="form-actions">
          <button
            type="submit"
            disabled={loading}
            className={`btn btn-primary ${loading ? 'disabled' : ''}`}
          >
            {loading ? "Creating..." : 
             mode === "inward" ? "Create Inward Entry" : 
             mode === "outward" ? "Create Outward Entry" : 
             "Create Gate Entry"}
          </button>

          <button
            type="button"
            onClick={resetForm}
            className="btn btn-secondary"
          >
            Reset Form
          </button>
        </div>
      </form>

      {error && (
        <div className="error-message">
          <strong>Error:</strong> {error}
        </div>
      )}

      {result && (
        <div className="success-message">
          <div className="success-header">
            <svg viewBox="0 0 24 24" width="24" height="24">
              <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
            </svg>
            <h3>Gate Entry Created Successfully!</h3>
          </div>
          <div className="success-content">
            <p>Gate Entry Number: <strong>{header.GateEntryNumber}</strong></p>
            <p>Date: {header.GateEntryDate}</p>
            <p>Vehicle: {header.VehicleNumber}</p>
          </div>
        </div>
      )}
    </div>
  );
}
