
//require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cookie = require('cookie');
const nodemailer = require('nodemailer');

const app = express();
app.use(express.json());

// NOTE: in dev we allow all origins. In production set specific origin.
app.use(cors({ origin: true, credentials: true }));

// // Configure these or set via .env
// const SAP_BASE = process.env.SAP_BASE || 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_GATEINWARD_OUTWARDDETA_CDS';
// const SAP_BASE_WEIGHTBRIDGE = process.env.SAP_BASE_WEIGHTBRIDGE || 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS';
// const SAP_USER = process.env.SAP_USER || 'BTPINTEGRATION';
// const SAP_PASS = process.env.SAP_PASS || 'BTPIntegration@1234567890';
// Configure these or set via .env
const SAP_BASE = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_GATEINWARD_OUTWARDDETA_CDS';
const SAP_BASE_WEIGHTBRIDGE = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS';
const SAP_BASE_InitialRegistration = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_INITIALREGISTRATION_CDS';
const SAP_BASE_UserAccess = 'https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_USERACCESS_CDS';
const SAP_USER = 'BTPINTEGRATION';
const SAP_PASS = 'BTPIntegration@1234567890';

const SAP_BASE_PO = 'https://my430243-api.s4hana.cloud.sap/sap/opu/odata4/sap/api_purchaseorder_2/srvd_a2x/sap/purchaseorder/0001/';
const SAP_BASE_SO = 'https://my430243-api.s4hana.cloud.sap/sap/opu/odata/sap/API_SALES_ORDER_SRV';
const SAP_BASE_OBD ='https://my430243-api.s4hana.cloud.sap/sap/opu/odata/sap/API_OUTBOUND_DELIVERY_SRV;v=0002'
const SAP_BASE_BILLING = 'https://my430243-api.s4hana.cloud.sap/sap/opu/odata4/sap/api_billingdocument/srvd_a2x/sap/billingdocument/0001/';
const SAP_USER_ST = 'BTPDEV_INTEGRATION2';
const SAP_PASS_ST = '-6WcdpJE5{/eC$jyT3Mw2HBiBF}Jv6pMLcb~rYN[';


if (!SAP_BASE || !SAP_USER || !SAP_PASS) {
  console.warn('Make sure SAP_BASE, SAP_USER and SAP_PASS env vars are set');
}

const sapAxios = axios.create({
  baseURL: SAP_BASE,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});

const sapAxiosWeight = axios.create({
  baseURL: SAP_BASE_WEIGHTBRIDGE,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});



const sapAxiosInitialRegistration = axios.create({
  baseURL: SAP_BASE_InitialRegistration,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});
const sapAxiosUserAccess = axios.create({
  baseURL: SAP_BASE_UserAccess,
  auth: { 
    username: SAP_USER, 
    password: SAP_PASS 
  }
});


const sapAxiosPO = axios.create({
  baseURL: SAP_BASE_PO,
  auth: { 
    username: SAP_USER_ST, 
    password: SAP_PASS_ST 
  }
});
const sapAxiosSO = axios.create({ 
  baseURL: SAP_BASE_SO,
  auth: { 
    username: SAP_USER_ST, 
    password: SAP_PASS_ST 
  }
});
const sapAxiosOBD = axios.create({
  baseURL: SAP_BASE_OBD,
  auth: { 
    username: SAP_USER_ST, 
    password: SAP_PASS_ST 
  }
});
const sapAxiosBilling = axios.create({
  baseURL: SAP_BASE_BILLING,
  auth: { 
    username: SAP_USER_ST, 
    password: SAP_PASS_ST 
  }
});
/* ---------- Utility helpers ---------- */

async function fetchCsrfToken() {
  try {
    const res = await sapAxios.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfToken error', err?.response?.status, err?.message);
    throw err;
  }
}

async function fetchCsrfTokenWeight() {
  try {
    const res = await sapAxiosWeight.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenWeight error', err?.response?.status, err?.message);
    throw err;
  }
}

/**
 * Fetch CSRF token + cookies for Initial Registration OData service.
 */
async function fetchCsrfTokenInitialRegistration() {
  try {
    const res = await sapAxiosInitialRegistration.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();

    if (!token) {
      console.warn('[WARN] No CSRF token returned for Initial Registration fetch');
    }
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenInitialRegistration error', err?.response?.status, err?.message);
    throw err;
  }
}

function sanitizePayloadForSapServerSide(input) {
  const payload = JSON.parse(JSON.stringify(input || {}));

  // Remove undefined/null and empty strings for top-level keys
  // BUT PRESERVE WeightDocNumber (the correct SAP field name)
  Object.keys(payload).forEach(k => {
    // Skip WeightDocNumber - let SAP validate it
    if (k === 'WeightDocNumber') return;
    
    if (payload[k] === undefined || payload[k] === null) delete payload[k];
    if (typeof payload[k] === 'string' && payload[k].trim() === '') delete payload[k];
  });

  // Normalize date if only date provided
  if (payload.GateEntryDate && payload.GateEntryDate.length === 10) {
    payload.GateEntryDate = `${payload.GateEntryDate}T00:00:00`;
  }
  if (payload.GateOutDate && payload.GateOutDate.length === 10) {
    payload.GateOutDate = `${payload.GateOutDate}T00:00:00`;
  }

  // Numeric cleaning for vendor weights and balances if provided as header-level fields
  for (let i = 1; i <= 5; i++) {
    const suffix = i === 1 ? '' : String(i);
    const wKey = `VendorInvoiceWeight${suffix}`;
    const bKey = `BalanceQty${suffix}`;

    if (wKey in payload) {
      const raw = payload[wKey];
      if (raw === '' || raw === null || raw === undefined) delete payload[wKey];
      else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[wKey] = normalized;
        } else {
          delete payload[wKey];
        }
      }
    }

    if (bKey in payload) {
      const raw = payload[bKey];
      if (raw === '' || raw === null || raw === undefined) delete payload[bKey];
      else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[bKey] = normalized;
        } else {
          delete payload[bKey];
        }
      }
    }
  }

  // Clean other numeric fields (TruckCapacity, TareWeight, GrossWeight, NetWeght, etc.)
  const numericFields = [
    'TruckCapacity', 'TareWeight', 'GrossWeight', 'NetWeght', 
    'DifferenceBT', 'ToleranceWeight', 'ActuallyWeight'
  ];
  
  numericFields.forEach(field => {
    if (field in payload) {
      const raw = payload[field];
      if (raw === '' || raw === null || raw === undefined) {
        delete payload[field];
      } else {
        const cleaned = String(raw).replace(/,/g, '').trim();
        const normalized = cleaned.replace(',', '.');
        if (/^-?\d+(\.\d+)?$/.test(normalized)) {
          payload[field] = normalized;
        } else {
          delete payload[field];
        }
      }
    }
  });

  return payload;
}

/* ---------- GateEntryNumber generator helpers ---------- */

// Build prefix like '251' (YY + series code)
function buildPrefixFromYearAndCode(yearInput, codeInput) {
  const now = new Date();
  const year = (yearInput && String(yearInput).length === 4) ? String(yearInput) : String(now.getFullYear());
  const yy = year.slice(-2);
  const code = String(codeInput || '1');
  return `${yy}${code}`; // e.g. '253' when year=2025 and code=3
}

function computeNextGateEntryNumber(prefix, latestGateNumber) {
  const suffixLength = 7; // 3(prefix) + 7 = 10 digits
  if (!latestGateNumber) return `${prefix}${String(1).padStart(suffixLength, '0')}`;
  const suffix = latestGateNumber.slice(prefix.length);
  const next = (parseInt(suffix, 10) || 0) + 1;
  return `${prefix}${String(next).padStart(suffixLength, '0')}`;
}

function computeNextWeightDocNumber(prefix, latestWeightNumber) {
  const suffixLength = 7; // 3(prefix) + 7 = 10 digits
  if (!latestWeightNumber) return `${prefix}${String(1).padStart(suffixLength, '0')}`; // FIXED
  const suffix = latestWeightNumber.slice(prefix.length); // FIXED
  const next = (parseInt(suffix, 10) || 0) + 1;
  return `${prefix}${String(next).padStart(suffixLength, '0')}`;
}

// Fetch latest gate entry number from SAP matching the prefix
async function getLatestGateEntryNumberFromSap(prefix) {
  try {
    const filter = `startswith(GateEntryNumber,'${prefix}')`;
    const path = `/YY1_GATEINWARD_OUTWARDDETA?$filter=${filter}&$orderby=GateEntryNumber desc&$top=1&$format=json`;
    const resp = await sapAxios.get(path);
    const results = resp.data?.d?.results || [];
    return results.length > 0 ? results[0].GateEntryNumber : null;
  } catch (err) {
    console.error('getLatestGateEntryNumberFromSap error', err?.message);
    return null;
  }
}

// Fetch latest weight document number from SAP matching the prefix
async function getLatestWeightDocNumberFromSap(prefix) {
  try {
    const filter = `startswith(WeightDocNumber,'${prefix}')`;
    const path = `/YY1_CAPTURINGWEIGHTDETAILS?$filter=${filter}&$orderby=WeightDocNumber desc&$top=1&$format=json`;
    console.log('[DEBUG] Fetching latest WeightDocNumber with path:', path);
    
    const resp = await sapAxiosWeight.get(path);
    console.log('[DEBUG] Weight query response:', JSON.stringify(resp.data, null, 2));
    
    const results = resp.data?.d?.results || [];
    const latestNumber = results.length > 0 ? results[0].WeightDocNumber : null;
    console.log('[DEBUG] Latest WeightDocNumber found:', latestNumber);
    
    return latestNumber;
  } catch (err) {
    console.error('getLatestWeightDocNumberFromSap error', err?.response?.status, err?.response?.data || err?.message);
    return null;
  }
}

/* ---------- API Routes ---------- */

// Simple request logger for debugging
app.use((req, res, next) => {
  console.log(`[API] ${req.method} ${req.originalUrl}`);
  if (Object.keys(req.body || {}).length) console.log(' body:', JSON.stringify(req.body));
  next();
});

// GET next gate number: /api/next-gatenumber?year=2025&code=3
app.get('/api/next-gatenumber', async (req, res) => {
  try {
    const { year, code } = req.query;
    const prefix = buildPrefixFromYearAndCode(year, code);
    const latest = await getLatestGateEntryNumberFromSap(prefix);
    const nextNumber = computeNextGateEntryNumber(prefix, latest);
    return res.json({ next: nextNumber });
  } catch (e) {
    console.error('next-gatenumber error', e?.response?.data || e.message);
    res.status(500).json({ error: e?.response?.data || e.message });
  }
});

// GET next weight number: /api/next-weightnumber?year=2025&code=1
app.get('/api/next-weightnumber', async (req, res) => {
  try {
    const { year, code } = req.query;
    const prefix = buildPrefixFromYearAndCode(year, code);
    console.log('[DEBUG] Generating next weight number for prefix:', prefix);
    
    const latest = await getLatestWeightDocNumberFromSap(prefix);
    const nextNumber = computeNextWeightDocNumber(prefix, latest);
    
    console.log('[DEBUG] Next WeightDocNumber:', nextNumber);
    return res.json({ next: nextNumber });
  } catch (e) {
    console.error('next-weightnumber error', e?.response?.data || e.message);
    res.status(500).json({ error: e?.response?.data || e.message });
  }
});

/* GET headers with query forwarding */
app.get('/api/headers', async (req, res) => {
  try {
    const rawQuery = (req.originalUrl || '').split('?')[1] || '';
    const sapPath = rawQuery ? `/YY1_GATEINWARD_OUTWARDDETA?${rawQuery}` : '/YY1_GATEINWARD_OUTWARDDETA?$top=50&$format=json';
    console.log('[API] forwarding to SAP ->', sapPath);
    const resp = await sapAxios.get(sapPath);
    res.json(resp.data);
  } catch (err) {
    console.error('Error fetching gate entry:', err?.response?.status, err?.response?.data || err?.message);
    res.status(500).json({ error: err?.response?.data || err?.message || 'Failed to fetch gate entry details' });
  }
});

/* GET header by GUID */
app.get('/api/headers/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const resp = await sapAxios.get(`/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')?$format=json`);
    res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* GET items for a header */
app.get('/api/headers/:id/items', async (req, res) => {
  const id = req.params.id;
  try {
    const path = `/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')/to_GateEntryItems?$format=json`;
    const resp = await sapAxios.get(path);
    res.json(resp.data);
  } catch (err) {
    console.error(err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST new header (deep insert with items) - Gate Entry */
app.post('/api/headers', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    const { token, cookies } = await fetchCsrfToken();

    const resp = await sapAxios.post('/YY1_GATEINWARD_OUTWARDDETA', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST header error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST Material Inward - Weight Bridge */
app.post('/api/headers/material/in', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    
    // Ensure WeightDocNumber exists (SAP requires it)
    // Note: The field is WeightDocNumber (not WeightDocumentNumber)
    if (!input.WeightDocNumber) {
      console.error('[ERROR] WeightDocNumber is missing!');
      return res.status(400).json({ 
        error: 'WeightDocNumber is required. Please ensure it is generated on the frontend.' 
      });
    }

    const { token, cookies } = await fetchCsrfTokenWeight();

    console.log('[DEBUG] Sanitized payload for Material Inward:', JSON.stringify(input, null, 2));

    const resp = await sapAxiosWeight.post('/YY1_CAPTURINGWEIGHTDETAILS', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Material Inward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST Material Outward - Weight Bridge */
app.post('/api/headers/material/out', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    
    // Ensure WeightDocNumber exists (SAP requires it)
    if (!input.WeightDocNumber) {
      console.error('[ERROR] WeightDocNumber is missing!');
      return res.status(400).json({ 
        error: 'WeightDocNumber is required. Please ensure it is generated on the frontend.' 
      });
    }

    const { token, cookies } = await fetchCsrfTokenWeight();

    console.log('[DEBUG] Sanitized payload for Material Outward:', JSON.stringify(input, null, 2));

    const resp = await sapAxiosWeight.post('/YY1_CAPTURINGWEIGHTDETAILS', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Material Outward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH update header */
app.patch('/api/headers/:id', async (req, res) => {
  const id = req.params.id;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEINWARD_OUTWARDDETA(guid'${id}')`;
    const resp = await sapAxios.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH header error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* POST create item under existing header */
app.post('/api/headers/:id/items', async (req, res) => {
  const id = req.params.id;
  const item = req.body;
  try {
    const { token, cookies } = await fetchCsrfToken();

    const resp = await sapAxios.post('/YY1_GATEENTRYITEMS_GATEINWA000', {
      ...item,
      SAP_PARENT_UUID: id
    }, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      }
    });

    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH update item */
app.patch('/api/items/:id', async (req, res) => {
  const id = req.params.id;
  const body = req.body;
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEENTRYITEMS_GATEINWA000(guid'${id}')`;
    const resp = await sapAxios.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* DELETE item */
app.delete('/api/items/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const { token, cookies } = await fetchCsrfToken();
    const path = `/YY1_GATEENTRYITEMS_GATEINWA000(guid'${id}')`;
    const resp = await sapAxios.delete(path, {
      headers: {
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('DELETE item error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});




const SAP_URL2 =
  "https://my430301-api.s4hana.cloud.sap/sap/opu/odata/sap/YY1_CAPTURINGWEIGHTDETAILS_CDS/YY1_CAPTURINGWEIGHTDETAILS";
const SAP_USER2 = "BTPINTEGRATION";
const SAP_PASS2 = "BTPIntegration@1234567890";
app.get("/api/header/weightdetails", async (req, res) => {
  try {
    const gateNumber = req.query.gateEntryNumber || req.query.GateEntryNumber;
    if (!gateNumber) {
      return res.status(400).json({ error: "Missing required parameter: gateNumber" });
    }

    // Proper OData filter string
    const filter = `$filter=GateEntryNumber eq '${gateNumber}'&$format=json`;
    const fullUrl = `${SAP_URL2}?${filter}`;

    console.log("[INFO] Fetching SAP Weight Details →", fullUrl);

    // Perform the SAP OData request
    const response = await axios.get(fullUrl, {
      auth: { username: SAP_USER2, password: SAP_PASS2 },
      headers: { Accept: "application/json" },
      validateStatus: () => true // prevents throwing error on 4xx
    });

    if (response.status >= 400) {
      console.error("[SAP ERROR]", response.status, response.data);
      return res.status(response.status).json({
        error: response.data || `SAP returned status ${response.status}`
      });
    }

    // Parse SAP OData V2 format
    const results =
      response.data?.d?.results || response.data?.value || (response.data?.d ? [response.data.d] : []);

    console.log(`[INFO] SAP returned ${results.length} record(s)`);

    // Filter only Indicators = "I" (Inward)
    const filteredResults = results.filter((r) => (r.Indicators || "").toUpperCase() === "I");

    // Return consistent JSON
    return res.json({
      d: {
        results: filteredResults
      }
    });
  } catch (error) {
    console.error("[API ERROR]", error.response?.status, error.response?.data || error.message);
    return res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message || "Failed to fetch SAP data"
    });
  }
});


// GET Material Outward records (Indicators='O')
app.get("/api/header/weightdetails/outward", async (req, res) => {
  try {
    const gateNumber = req.query.gateEntryNumber || req.query.GateEntryNumber;
    if (!gateNumber) {
      return res.status(400).json({ error: "Missing required parameter: gateEntryNumber" });
    }

    const filter = `$filter=GateEntryNumber eq '${gateNumber}'&$format=json`;
    const fullUrl = `${SAP_URL2}?${filter}`;

    console.log("[INFO] Fetching SAP Weight Details (Outward) →", fullUrl);

    const response = await axios.get(fullUrl, {
      auth: { username: SAP_USER2, password: SAP_PASS2 },
      headers: { Accept: "application/json" },
      validateStatus: () => true
    });

    if (response.status >= 400) {
      console.error("[SAP ERROR]", response.status, response.data);
      return res.status(response.status).json({
        error: response.data || `SAP returned status ${response.status}`
      });
    }

    const results =
      response.data?.d?.results || response.data?.value || (response.data?.d ? [response.data.d] : []);

    console.log(`[INFO] SAP returned ${results.length} record(s)`);

    // Filter only Indicators = "O" (Outward)
    const filteredResults = results.filter((r) => (r.Indicators || "").toUpperCase() === "O");

    return res.json({
      d: {
        results: filteredResults
      }
    });
  } catch (error) {
    console.error("[API ERROR]", error.response?.status, error.response?.data || error.message);
    return res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message || "Failed to fetch SAP data"
    });
  }
});

// GET Material Outward records by Vendor Invoice Number (Indicators='O')
app.get("/api/weightdetails/vendorinvoice/:VendorInvoiceNumber", async (req, res) => {
  try {
    const vendorInvoiceNumber = req.params.VendorInvoiceNumber;
    if (!vendorInvoiceNumber) {
      return res.status(400).json({ error: "Missing required parameter: vendorInvoiceNumber" });
    }

    const filter = `$filter=VendorInvoiceNumber eq '${vendorInvoiceNumber}'&$format=json`;
    const fullUrl = `${SAP_URL2}?${filter}`;

    console.log("[INFO] Fetching SAP Weight Details (Outward by VendorInvoiceNumber) →", fullUrl);

    const response = await axios.get(fullUrl, {
      auth: { username: SAP_USER2, password: SAP_PASS2 },
      headers: { Accept: "application/json" },
      validateStatus: () => true
    });

    if (response.status >= 400) {
      console.error("[SAP ERROR]", response.status, response.data);
      return res.status(response.status).json({
        error: response.data || `SAP returned status ${response.status}`
      });
    }

    const results =
      response.data?.d?.results || response.data?.value || (response.data?.d ? [response.data.d] : []);

    console.log(`[INFO] SAP returned ${results.length} record(s)`);

    // Filter only Indicators = "O" (Outward)
    const filteredResults = results.filter((r) => (r.Indicators || "").toUpperCase() === "O");

return res.json({ d: { results } });
  } catch (error) {
    console.error("[API ERROR]", error.response?.status, error.response?.data || error.message);
    return res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message || "Failed to fetch SAP data"
    });
  }
});



/* PATCH Update Material Inward (for tare weight) */
app.patch('/api/headers/material/:uuid', async (req, res) => {
  const uuid = req.params.uuid;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfTokenWeight();
    
    // REMOVE $format=json from PATCH - SAP doesn't allow query options on updates
    const path = `/YY1_CAPTURINGWEIGHTDETAILS(guid'${uuid}')`;
    
    console.log('[DEBUG] Updating Material Inward:', path);
    console.log('[DEBUG] Update payload:', JSON.stringify(body, null, 2));
    
    const resp = await sapAxiosWeight.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        'If-Match': '*', // to avoid 412 Precondition Failed
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH Material Inward error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

// Initial Registration POST
app.post('/api/initial-registration', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    const { token, cookies } = await fetchCsrfTokenInitialRegistration();
    const resp = await sapAxiosInitialRegistration.post('/YY1_INITIALREGISTRATION', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
    });
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('POST Initial Registration error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* GET Initial Registration list with optional search and count */
app.get('/api/initial-registrations', async (req, res) => {
  try {
    const top = Math.min(parseInt(req.query.top, 10) || 50, 200); // safety cap
    const search = (req.query.search || '').trim();
    const wantCount = String(req.query.count || 'false').toLowerCase() === 'true';

    // Build OData $filter using substringof (OData V2 compatible)
    let filterExpr = '';
    if (search) {
      const s = search.replace(/'/g, "''"); // escape single quotes for OData
      // Use substringof instead of contains - OData V2 syntax
      const clauses = [
        `substringof('${s}',SalesDocument)`,
        `substringof('${s}',VehicleNumber)`,
        `substringof('${s}',Transporter)`,
        `substringof('${s}',SAP_Description)`
      ];
      filterExpr = clauses.join(' or ');
    }

    let path = `/YY1_INITIALREGISTRATION?$format=json&$top=${top}`;
    if (filterExpr) path += `&$filter=${encodeURIComponent(filterExpr)}`;
    if (wantCount) path += `&$inlinecount=allpages`;

    console.log('[DEBUG] Initial Registration query path:', path);

    const resp = await sapAxiosInitialRegistration.get(path);

    // Normalize OData V2 shape
    const d = resp.data?.d || {};
    const results = Array.isArray(d.results) ? d.results : (Array.isArray(resp.data?.value) ? resp.data.value : []);
    const count = d.__count != null ? Number(d.__count) : results.length;

    return res.json({ d: { __count: count, results } });
  } catch (err) {
    console.error('GET Initial Registrations error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

/* PATCH Update Initial Registration (e.g., change Status to Failed) */
app.patch('/api/initial-registration/:uuid', async (req, res) => {
  const uuid = req.params.uuid;
  const body = sanitizePayloadForSapServerSide(req.body);
  try {
    const { token, cookies } = await fetchCsrfTokenInitialRegistration();
    const path = `/YY1_INITIALREGISTRATION(guid'${uuid}')`;
    
    console.log('[DEBUG] Updating Initial Registration:', path, body);
    
    const resp = await sapAxiosInitialRegistration.patch(path, body, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies,
      },
      validateStatus: status => status < 500
    });
    
    if (resp.status === 204) return res.status(204).send();
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('PATCH Initial Registration error', err?.response?.status, err?.response?.data || err?.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

// Email configuration (add before app.listen)
const transporter = nodemailer.createTransport({
  service: 'gmail', // or 'outlook', 'yahoo', etc.
  auth: {
    user: 'chinnasukumar056@gmail.com', // Replace with your Gmail
    pass: 'fjzb fxne zvoe xnae'      // Replace with Gmail App Password (not regular password)
  }
});

// Email notification endpoint
app.post('/api/send-notification', async (req, res) => {
  try {
    const { gateEntryNumber, weightDocNumber, vehicleNumber, grossWeight, date } = req.body;

    const mailOptions = {
      from: 'chinnasukumar056@gmail.com',
      to: 'n.sukumar056@gmail.com',
      subject: `✅ Gate Entry Created - ${gateEntryNumber}`,
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #f5f5f5;">
          <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="color: #4CAF50; margin-bottom: 20px;">✅ New Gate Entry Created</h2>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Gate Entry Number:</td>
                <td style="padding: 12px 0; color: #333;">${gateEntryNumber}</td>
              </tr>
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Weight Document Number:</td>
                <td style="padding: 12px 0; color: #333;">${weightDocNumber || 'N/A'}</td>
              </tr>
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Vehicle Number:</td>
                <td style="padding: 12px 0; color: #333;">${vehicleNumber}</td>
              </tr>
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Gross Weight:</td>
                <td style="padding: 12px 0; color: #333;">${grossWeight ? grossWeight + ' MT' : 'N/A'}</td>
              </tr>
              <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Date:</td>
                <td style="padding: 12px 0; color: #333;">${date}</td>
              </tr>
              <tr>
                <td style="padding: 12px 0; font-weight: bold; color: #555;">Created At:</td>
                <td style="padding: 12px 0; color: #333;">${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td>
              </tr>
            </table>
            
            <div style="margin-top: 30px; padding: 15px; background: #e8f5e9; border-left: 4px solid #4CAF50; border-radius: 5px;">
              <p style="margin: 0; color: #2e7d32;">
                <strong>Status:</strong> Gate Entry and Weight Document created successfully in SAP system.
              </p>
            </div>
          </div>
        </div>
      `
    };

    await transporter.sendMail(mailOptions);
    console.log('✅ Email notification sent successfully');
    res.json({ success: true, message: 'Email sent successfully' });
  } catch (error) {
    console.error('❌ Email send error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * Parse SAP error into user-friendly message
 * Converts technical SAP errors into simple messages clients can understand
 */
function parseSapErrorToFriendlyMessage(err) {
  try {
    // Extract error data from various possible structures
    const errData = err?.response?.data?.error?.error || err?.response?.data?.error || err?.response?.data;
    
    if (!errData) {
      return err?.message || 'An unexpected error occurred';
    }

    // Extract the main error message
    const message = errData.message?.value || errData.message || '';
    
    // Common SAP error patterns and their friendly translations
    const patterns = [
      {
        // Property validation errors - extract field name and value
        regex: /Property '(\w+)' at offset '\d+' has invalid value '([^']+)'/i,
        format: (match) => {
          const fieldName = match[1];
          const invalidValue = match[2];
          
          // Convert technical field names to user-friendly names
          const fieldMap = {
            'PurchaseOrderNumber': 'Purchase Order 1',
            'PurchaseOrderNumber2': 'Purchase Order 2',
            'PurchaseOrderNumber3': 'Purchase Order 3',
            'PurchaseOrderNumber4': 'Purchase Order 4',
            'PurchaseOrderNumber5': 'Purchase Order 5',
            'Material': 'Material 1',
            'Material2': 'Material 2',
            'Material3': 'Material 3',
            'Material4': 'Material 4',
            'Material5': 'Material 5',
            'MaterialDescription': 'Material Description 1',
            'MaterialDescription2': 'Material Description 2',
            'MaterialDescription3': 'Material Description 3',
            'MaterialDescription4': 'Material Description 4',
            'MaterialDescription5': 'Material Description 5',
            'Vendor': 'Vendor 1',
            'Vendor2': 'Vendor 2',
            'Vendor3': 'Vendor 3',
            'Vendor4': 'Vendor 4',
            'Vendor5': 'Vendor 5',
            'VendorName': 'Vendor Name 1',
            'VendorName2': 'Vendor Name 2',
            'VendorName3': 'Vendor Name 3',
            'VendorName4': 'Vendor Name 4',
            'VendorName5': 'Vendor Name 5',
            'VendorInvoiceNumber': 'Vendor Invoice Number 1',
            'VendorInvoiceNumber2': 'Vendor Invoice Number 2',
            'VendorInvoiceNumber3': 'Vendor Invoice Number 3',
            'VendorInvoiceNumber4': 'Vendor Invoice Number 4',
            'VendorInvoiceNumber5': 'Vendor Invoice Number 5',
            'VendorInvoiceWeight': 'Vendor Invoice Weight 1',
            'VendorInvoiceWeight2': 'Vendor Invoice Weight 2',
            'VendorInvoiceWeight3': 'Vendor Invoice Weight 3',
            'VendorInvoiceWeight4': 'Vendor Invoice Weight 4',
            'VendorInvoiceWeight5': 'Vendor Invoice Weight 5',
            'VendorInvoiceDate': 'Vendor Invoice Date 1',
            'VendorInvoiceDate2': 'Vendor Invoice Date 2',
            'VendorInvoiceDate3': 'Vendor Invoice Date 3',
            'VendorInvoiceDate4': 'Vendor Invoice Date 4',
            'VendorInvoiceDate5': 'Vendor Invoice Date 5',
            'BalanceQty': 'Balance Quantity 1',
            'BalanceQty2': 'Balance Quantity 2',
            'BalanceQty3': 'Balance Quantity 3',
            'BalanceQty4': 'Balance Quantity 4',
            'BalanceQty5': 'Balance Quantity 5',
            'GateEntryNumber': 'Gate Entry Number',
            'WeightDocNumber': 'Weight Document Number',
            'VehicleNumber': 'Vehicle Number',
            'TruckNumber': 'Truck Number',
            'GateEntryDate': 'Gate Entry Date',
            'FiscalYear': 'Fiscal Year',
            'TransporterCode': 'Transporter Code',
            'TransporterName': 'Transporter Name',
            'DriverName': 'Driver Name',
            'DriverPhoneNumber': 'Driver Phone Number',
            'LRGCNumber': 'LR/GC Number',
            'TruckCapacity': 'Truck Capacity',
            'TareWeight': 'Tare Weight',
            'GrossWeight': 'Gross Weight',
            'NetWeght': 'Net Weight'
          };
          
          const friendlyFieldName = fieldMap[fieldName] || fieldName.replace(/([A-Z])/g, ' $1').trim();
          return `${friendlyFieldName} has invalid value '${invalidValue}'. Please check and correct it.`;
        }
      },
      {
        // Required field errors
        regex: /Property '(\w+)' is required|mandatory field '(\w+)'/i,
        format: (match) => {
          const fieldName = match[1] || match[2];
          return `${fieldName.replace(/([A-Z])/g, ' $1').trim()} is required. Please provide a value.`;
        }
      },
      {
        // Duplicate key errors
        regex: /duplicate.*key|already exists|unique constraint/i,
        format: () => 'This record already exists in the system. Please check your data.'
      },
      {
        // Type mismatch errors
        regex: /type mismatch|invalid type|cannot convert/i,
        format: () => 'Invalid data type provided. Please check that all fields have the correct format.'
      },
      {
        // Date format errors
        regex: /invalid date|date format|cannot parse date/i,
        format: () => 'Invalid date format. Please use the correct date format (YYYY-MM-DD).'
      },
      {
        // Numeric validation errors
        regex: /invalid numeric|not a number|numeric overflow/i,
        format: () => 'Invalid number format. Please enter a valid numeric value.'
      }
    ];

    // Try to match patterns
    for (const pattern of patterns) {
      const match = message.match(pattern.regex);
      if (match) {
        return pattern.format(match);
      }
    }

    // If no pattern matches but we have a clean message, return it
    if (message && message.length < 200 && !message.includes('{')) {
      return message;
    }

    // Default fallback message
    return 'An error occurred while processing your request. Please check your input and try again.';
    
  } catch (parseError) {
    console.error('Error parsing SAP error:', parseError);
    return 'An unexpected error occurred. Please contact support if the issue persists.';
  }
}

app.get('/api/purchaseorder/:poNumber', async (req, res) => {
  const poNumber = req.params.poNumber;
  try {
    const headerPath = `/PurchaseOrder?$filter=PurchaseOrder eq '${poNumber}'&$top=1&$format=json`;
    const itemPath = `/PurchaseOrderItem?$filter=PurchaseOrder eq '${poNumber}'&$format=json`;

    const [headerResponse, itemResponse] = await Promise.all([
      sapAxiosPO.get(headerPath),
      sapAxiosPO.get(itemPath)
    ]);

    const headerData = headerResponse.data.value?.[0] || {};
    const items = itemResponse.data.value || [];

    res.json({
      ...headerData,
      items: items
    });
  } catch (error) {
    console.error('Error fetching PO and items:', error);
    res.status(500).json({ error: 'Failed to fetch PO and items' });
  }
});

// Get PO details by SupplierRespSalesPersonName (header first, then items)
app.get('/api/po-permitnumber/:permitnumber', async (req, res) => {
  const permitnumber = req.params.permitnumber;
  try {
    // 1. Get header by SupplierRespSalesPersonName
    const headerPath = `/PurchaseOrder?$filter=SupplierRespSalesPersonName eq '${permitnumber}'&$top=1&$format=json`;
    const headerResponse = await sapAxiosPO.get(headerPath);
    const headerData = headerResponse.data.value?.[0];
    if (!headerData || !headerData.PurchaseOrder) {
      return res.status(404).json({ error: 'No PO found for given salesPersonName' });
    }
    // 2. Now get line items by PO number
    const poNumToUse = headerData.PurchaseOrder;
    const itemPath = `/PurchaseOrderItem?$filter=PurchaseOrder eq '${poNumToUse}'&$format=json`;
    const itemResponse = await sapAxiosPO.get(itemPath);
    const items = itemResponse.data.value || [];
    return res.json({ ...headerData, items });
  } catch (error) {
    console.error('Error fetching PO by salesPersonName:', error);
    res.status(500).json({ error: 'Failed to fetch PO and items by salesPersonName' });
  }
});

// GET User Access by username
app.get('/api/useraccess/:username', async (req, res) => {
  const username = req.params.username;
  try {
    // Remove $format=json and use proper OData V4 syntax
    const path = `/YY1_USERACCESS?$filter=UserName eq '${username}'`;
    
    console.log('[USERACCESS] Requesting SAP URL:', SAP_BASE_UserAccess + path);

    const response = await sapAxiosUserAccess.get(path, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    // Handle different OData response formats
    let results = [];
    if (response.data && response.data.value) {
      // OData V4 format
      results = response.data.value;
    } else if (response.data && response.data.d && response.data.d.results) {
      // OData V2 format with "d" wrapper
      results = response.data.d.results;
    } else if (response.data && response.data.d) {
      // OData V2 single result
      results = [response.data.d];
    } else {
      results = response.data || [];
    }

    console.log('[USERACCESS] Found', results.length, 'records');
    return res.json({
      success: true,
      count: results.length,
      data: results
    });
    
  } catch (error) {
    console.error('Error fetching user access:');
    
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
      
      // More specific error handling
      if (error.response.status === 400) {
        return res.status(400).json({
          error: 'Bad request to SAP system',
          message: error.response.data.error?.message?.value || 'Invalid request format',
          details: 'Try without $format parameter or check OData version'
        });
      } else if (error.response.status === 401) {
        return res.status(401).json({ error: 'Authentication failed' });
      } else if (error.response.status === 404) {
        return res.status(404).json({ error: 'User access service not found' });
      }
      
      return res.status(error.response.status).json({
        error: 'SAP system error',
        status: error.response.status,
        message: error.response.data
      });
    } else {
      console.error('Network error:', error.message);
      return res.status(500).json({ 
        error: 'Network error', 
        message: error.message 
      });
    }
  }
});

//Sales Order Details
// GET /api/salesorders?search=12
app.get('/api/salesorders/:soNumber', async (req, res) => {
  const soNumber = req.params.soNumber;
  try {
    // Expand items using $expand=to_Item
    const path = `/A_SalesOrder('${soNumber}')?$expand=to_Item&$format=json`;
    const resp = await sapAxiosSO.get(path);
    const so = resp.data?.d || {};
    // Flatten items
    const items = so.to_Item?.results || [];
    res.json({
      SalesDocument: so.SalesOrder,
      ...so,
      items
    });
  } catch (err) {
    console.error('SO fetch error', err?.response?.data || err.message);
    res.status(500).json({ error: 'Failed to fetch sales order' });
  }
});

// ...existing code...

// //GET /api/salesorders?search=12
// app.get('/api/salesorders', async (req, res) => {
//   const search = (req.query.search || '').trim();
//   if (!search) {
//     return res.status(400).json({ error: 'Missing search parameter' });
//   }
//   try {
//     // OData V2: use substringof for partial match
//     const filter = `substringof('${search}',SalesOrder)`;
//     const path = `/A_SalesOrder?$filter=${filter}&$top=10&$format=json`;
//     const resp = await sapAxiosSO.get(path);
//     const results = resp.data?.d?.results || [];
//     // Return only SO numbers (or more fields if needed)
//     res.json(results.map(r => ({
//       SalesOrder: r.SalesOrder,
//       ...r // include more fields if needed
//     })));
//   } catch (err) {
//     console.error('SO suggest error', err?.response?.data || err.message);
//     res.status(500).json({ error: 'Failed to fetch SO suggestions' });
//   }
// });

// GET /api/salesorders?search=12
app.get('/api/salesorders', async (req, res) => {
  const search = (req.query.search || '').trim();
  if (!search) {
    return res.status(400).json({ error: 'Missing search parameter' });
  }
  try {
    // 1. Fetch SO headers matching the search
    const filter = `substringof('${search}',SalesOrder)`;
    const headerPath = `/A_SalesOrder?$filter=${filter}&$top=10&$format=json`;
    const headerResp = await sapAxiosSO.get(headerPath);
    const headers = headerResp.data?.d?.results || [];

    // 2. For each SO, fetch its line items
    // Collect all SO numbers
    const soNumbers = headers.map(h => h.SalesOrder);
    if (soNumbers.length === 0) return res.json([]);

    // Fetch all line items for these SOs in one call (OData V2: use 'or' in filter)
    const itemFilter = soNumbers.map(so => `SalesOrder eq '${so}'`).join(' or ');
    const itemPath = `/A_SalesOrderItem?$filter=${encodeURIComponent(itemFilter)}&$format=json`;
    const itemResp = await sapAxiosSO.get(itemPath);
    const items = itemResp.data?.d?.results || [];

    // 3. Group items by SO number
    const itemsBySO = {};
    items.forEach(item => {
      if (!itemsBySO[item.SalesOrder]) itemsBySO[item.SalesOrder] = [];
      itemsBySO[item.SalesOrder].push(item);
    });

    // 4. Build response: for each SO, include header fields and line items
    const result = headers.map(h => ({
      SalesDocument: h.SalesOrder,
      Customer: h.SoldToParty,
      CustomerName: h.SoldToPartyName,
      // Add more header fields if needed
      items: (itemsBySO[h.SalesOrder] || []).map(li => ({
        Material: li.Material,
        MaterialDescription: li.MaterialDescription,
        BalanceQty: li.ConfdDelivQtyInOrderQtyUnit, // or the correct field for balance qty
        // Add more line item fields if needed
      }))
    }));

    res.json(result);
  } catch (err) {
    console.error('SO suggest error', err?.response?.data || err.message);
    res.status(500).json({ error: 'Failed to fetch SO suggestions' });
  }
});

// Fetch CSRF token for Outbound Delivery OData service
async function fetchCsrfTokenOutboundDelivery() {
  try {
    const res = await sapAxiosOBD.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenOutboundDelivery error', err?.response?.status, err?.message);
    throw err;
  }
}

// POST Outbound Delivery
app.post('/api/outbounddelivery', async (req, res) => {
  try {
    const input = sanitizePayloadForSapServerSide(req.body);
    const { token, cookies } = await fetchCsrfTokenOutboundDelivery();
    const resp = await sapAxiosOBD.post('/A_OutbDeliveryHeader', input, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        Cookie: cookies
      }
    });
    res.status(resp.status).json(resp.data);
  } catch (err) {
    console.error('Outbound Delivery post error', err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message || 'Failed to create outbound delivery' });
  }
});

// Fetch CSRF token for Goods Issue OData service
async function fetchCsrfTokenGoodsIssue() {
  try {
    const res = await sapAxiosOBD.get('/', {
      headers: { 'x-csrf-token': 'Fetch' },
      validateStatus: () => true,
    });
    const token = res.headers['x-csrf-token'];
    const setCookie = res.headers['set-cookie'] || res.headers['Set-Cookie'] || [];
    const cookies = Array.isArray(setCookie)
      ? setCookie
          .map(c => {
            try {
              const parsed = cookie.parse(c);
              return Object.entries(parsed).map(([k, v]) => `${k}=${v}`).join('; ');
            } catch (e) {
              return c.split(';')[0];
            }
          })
          .join('; ')
      : (setCookie || '').toString();
    return { token, cookies };
  } catch (err) {
    console.error('fetchCsrfTokenGoodsIssue error', err?.response?.status, err?.message);
    throw err;
  }
}

// app.post('/api/goodsissue', async (req, res) => {
//   try {
//     const deliveryDocument = req.body.DeliveryDocument; // Assuming the body has { "DeliveryDocument": "80000007" }
    
//     // Check if the parameter is provided
//     if (!deliveryDocument) {
//       return res.status(400).json({ error: "DeliveryDocument parameter is required" });
//     }

//     const { token, cookies } = await fetchCsrfTokenGoodsIssue();
    
//     // Pass the DeliveryDocument as a query parameter in the URL
//     const url = `/PostGoodsIssue?DeliveryDocument='${encodeURIComponent(deliveryDocument)}'`;
    
//     // Send the POST request with an empty body or the required body structure
//     const resp = await sapAxiosOBD.post(url, {}, { // Empty body object
//       headers: {
//         'Content-Type': 'application/json',
//         'x-csrf-token': token,
//         'If-Match': '*',
//         Cookie: cookies
//       }
//     });
    
//     res.status(resp.status).json(resp.data);
//   } catch (err) {
//     console.error('Goods Issue post error', err?.response?.status, err?.response?.data || err.message);
//     res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message || 'Failed to create goods issue' });
//   }
// });

app.post('/api/goodsissue-and-invoice', async (req, res) => {
  try {
    const deliveryDocument = req.body.DeliveryDocument;
    if (!deliveryDocument) {
      return res.status(400).json({ error: "DeliveryDocument parameter is required" });
    }

    // 1. Post Goods Issue
    const { token, cookies } = await fetchCsrfTokenGoodsIssue();
    const url = `/PostGoodsIssue?DeliveryDocument='${encodeURIComponent(deliveryDocument)}'`;
    const goodsIssueResp = await sapAxiosOBD.post(url, {}, {
      headers: {
        'Content-Type': 'application/json',
        'x-csrf-token': token,
        'If-Match': '*',
        Cookie: cookies
      }
    });

    // 2. If successful, create billing document
    if (goodsIssueResp.status === 201 || goodsIssueResp.status === 200) {
      const billingPayload = {
        "_Control": {
          "DefaultBillingDocumentType": "F2",
          "AutomPostingToAcctgIsDisabled": true
        },
        "_Reference": [
          {
            "SDDocument": deliveryDocument,
            "SDDocumentCategory": "J"
          }
        ]
      };
      const billingUrl = `/BillingDocument/SAP__self.CreateFromSDDocument?DeliveryDocument='${encodeURIComponent(deliveryDocument)}'`;
      const billingResp = await sapAxiosBilling.post(billingUrl, billingPayload, {
        headers: {
          'Content-Type': 'application/json',
          'x-csrf-token': token,
          'If-Match': '*',
          Cookie: cookies
        }
      });
      return res.status(billingResp.status).json(billingResp.data);
    } else {
      return res.status(goodsIssueResp.status).json({ error: 'Goods issue failed', details: goodsIssueResp.data });
    }
  } catch (err) {
    console.error('Goods Issue + Invoice error', err?.response?.status, err?.response?.data || err.message);
    res.status(err?.response?.status || 500).json({ error: err?.response?.data || err?.message });
  }
});

// Start server
const port = process.env.PORT || 4200;
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));


